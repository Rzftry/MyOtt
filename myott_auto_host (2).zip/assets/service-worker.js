// proxy: service worker moved to root; keep copy here
self.addEventListener('fetch',()=>{});